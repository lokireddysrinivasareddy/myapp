
//For First
document.querySelector('.for_scroll').onscroll;
        let myvalue
        let count_1=0;
        let num_var_1 = document.querySelector(".num_1");
        // document.querySelector(".items_menu").style.visibility = "hidden";
        document.querySelector(".first_button").style.visibility = "hidden";
        // document.querySelector(".btn").classList.remove('.first_button');
        document.querySelector('#cnt1').addEventListener("keydown",function(e){
            if(e.keyCode>=48 && e.keyCode<=90 || e.keyCode>=96 && e.keyCode<=105){
                document.querySelector(".first_button").style.visibility ='visible';
            }
            // else{
            //     document.querySelector(".first_button").style.visibility = "hidden";
            // }
            
        })

        // document.querySelector('#dots_for').addEventListener('click', function(){
        //     document.querySelector(".items_menu").style.visibility = "visible";
        // })

        document.querySelector(".first_button").addEventListener('click',function() {
            let myv1=document.querySelector('#cnt1').value;
            if(myv1){
            let myele = document.createElement("div");
            count_1+=1;
            
         let forscroll = document.querySelector('.for_1');
        forscroll.append(myele);
        myvalue = document.querySelector('#cnt1').value;
        const html = `<div class="my_static_contnet mt-2 d-inline-flex border-bottom" draggable="true">
                                        <i class="fas fa-align-justify dragicon"></i>
                                        <h4 class="cont">${myvalue}</h4>
                                        <div class="dropdown">
                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><i class="fas fa-ellipsis-v dots"></i>
                        </button>
                        <ul class="dropdown-menu pull-right">
                        <li><a href="#">Mark as Completed</a></li>
                        <li><a href="#">Focus Mode</a></li>
                        <li><a href="#">Delegate...</a></li>
                        <li><a href="#" class="delete_class" onclick="remove1(this)">Delete</a></li>
                        </ul>
                        </div>
                        <i class="fas fa-check tick"></i>
                        </div>`;
        forscroll.insertAdjacentHTML('afterbegin',html);
        document.querySelector('#cnt1').value ='';
        document.querySelector(".first_button").style.visibility = "hidden";
        num_var_1.textContent=count_1;
    }
    else{
        document.querySelector(".first_button").style.visibility = "hidden";
    }

        });
        
        

        //For Second
        let count_2 = 0;
        let num_var_2 = document.querySelector(".num_2");
        document.querySelector(".second_btn").style.visibility = "hidden";
        
        document.querySelector('#cnt2').addEventListener("keydown",function(e){
            if(e.keyCode>=48 && e.keyCode<=90 || e.keyCode>=96 && e.keyCode<=105){
                document.querySelector(".second_btn").style.visibility ='visible';
            }
        })
        document.querySelector('.second_btn').addEventListener('click',function(){
            let myv2=document.querySelector('#cnt2').value;
            if(myv2){

            let myele = document.createElement("div");
            count_2+=1;
            myele.classList.add('my_static_content');
            
        let forscroll = document.querySelector('.for_2');
        forscroll.append(myele);
        myvalue = document.querySelector('#cnt2').value;
        const html = `<div class="my_static_contnet mt-2 d-flex border-bottom">
                                        <i class="fas fa-align-justify dragicon"></i>
                                        <h4 class="cont">${myvalue}</h4>
                                        <div class="dropdown">
                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><i class="fas fa-ellipsis-v dots"></i>
                        </button>
                        <ul class="dropdown-menu pull-right">
                        <li><a href="#">Mark as Completed</a></li>
                        <li><a href="#">Focus Mode</a></li>
                        <li><a href="#">Delegate...</a></li>
                        <li><a href="#" class="delete_class" onclick="remove2(this)">Delete</a></li>
                        </ul>
                        </div>
                        <i class="fas fa-check tick"></i>
                        </div>`;
        forscroll.insertAdjacentHTML('afterbegin',html);
        num_var_2.textContent = count_2;
        document.querySelector('#cnt2').value ='';
        document.querySelector(".second_btn").style.visibility = "hidden";
    }
    else{
        document.querySelector(".second_btn").style.visibility = "hidden";
    }
        });



        // For Third
        let count_3 = 0;
        let num_var_3 = document.querySelector(".num_3");
        document.querySelector(".third_button").style.visibility = "hidden";
        
        document.querySelector('#cnt3').addEventListener("keydown",function(e){
            if(e.keyCode>=48 && e.keyCode<=90 || e.keyCode>=96 && e.keyCode<=105){
                document.querySelector(".third_button").style.visibility ='visible';
            }
        });
        document.querySelector('.third_button').addEventListener('click',function(){
            let myv3=document.querySelector('#cnt3').value;
            if(myv3){
            let myele = document.createElement("div");
            myele.classList.add('my_static_content');
            count_3+=1;
        let forscroll = document.querySelector('.for_3');
        forscroll.append(myele);
        myvalue = document.querySelector('#cnt3').value;
        const html = `<div class="my_static_contnet mt-2 d-flex border-bottom">
                                        <i class="fas fa-align-justify dragicon"></i>
                                        <h4 class="cont">${myvalue}</h4>
                                        <div class="dropdown">
                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><i class="fas fa-ellipsis-v dots"></i>
                        </button>
                        <ul class="dropdown-menu pull-right">
                        <li><a href="#">Mark as Completed</a></li>
                        <li><a href="#">Focus Mode</a></li>
                        <li><a href="#">Delegate...</a></li>
                        <li><a href="#" class="delete_class" onclick="remove3(this)">Delete</a></li>
                        </ul>
                        </div>
                        <i class="fas fa-check tick"></i>
                        </div>`;
        forscroll.insertAdjacentHTML('afterbegin',html);
        num_var_3.textContent = count_3;
        document.querySelector('#cnt3').value ='';
        document.querySelector(".third_button").style.visibility = "hidden";
    }
    else{
        document.querySelector(".third_button").style.visibility = "hidden";
    }
        });


        //For Fourth

        let count_4 = 0;
        let num_var_4 = document.querySelector(".num_4");
        document.querySelector(".fourth_button").style.visibility = "hidden";
        
        
        document.querySelector('#cnt4').addEventListener("keydown",function(e){
            // let ar= e.keyCode;
            console.log(String.fromCharCode(e.keyCode));
        //     var value = this.value + String.fromCharCode(e.keyCode);
        // console.log(` key ${value} pressed`);
            if(e.keyCode>=48 && e.keyCode<=90 || e.keyCode>=96 && e.keyCode<=105){
                document.querySelector(".fourth_button").style.visibility ='visible';
            }
        })
        document.querySelector('.fourth_button').addEventListener('click',function(){
            let myv4=document.querySelector('#cnt4').value;
            if(myv4){
            let myele = document.createElement("div");
            myele.classList.add('my_static_content');
            count_4+=1;
            
        let forscroll = document.querySelector('.for_4');
        forscroll.append(myele);
        myvalue = document.querySelector('#cnt4').value;
        const html = `<div class="my_static_contnet mt-2 d-flex border-bottom">
                                        <i class="fas fa-align-justify dragicon"></i>
                                        <h4 class="cont">${myvalue}</h4>
                                        <div class="dropdown">
                        <button class="btn dropdown-toggle" type="button" data-toggle="dropdown"><i class="fas fa-ellipsis-v dots"></i>
                        </button>
                        <ul class="dropdown-menu pull-right">
                        <li><a href="#">Mark as Completed</a></li>
                        <li><a href="#">Focus Mode</a></li>
                        <li><a href="#">Delegate...</a></li>
                        <li><a href="#" class="delete_class" onclick="remove4(this)">Delete</a></li>
                        </ul>
                        </div>
                        <i class="fas fa-check tick"></i>
                        </div>`;
        forscroll.insertAdjacentHTML('afterbegin',html);
        num_var_4.textContent = count_4;
        document.querySelector('#cnt4').value ='';
        document.querySelector(".fourth_button").style.visibility = "hidden";
    }
    else{
        document.querySelector(".fourth_button").style.visibility = "hidden";
    }
        });

    function remove1(val)    
    {
        $(val).parent().parent().parent().parent().remove();
        count_1-=1;
        document.querySelector(".num_1").textContent=count_1;
    };

    function remove2(val)    
    {
        $(val).parent().parent().parent().parent().remove();
        count_2-=1;
        document.querySelector(".num_2").textContent=count_2;
    };

    function remove3(val)    
    {
        $(val).parent().parent().parent().parent().remove();
        count_3-=1;
        document.querySelector(".num_3").textContent=count_3;
    };

    function remove4(val)    
    {
        $(val).parent().parent().parent().parent().remove();
        count_4-=1;
        document.querySelector(".num_4").textContent=count_4;
    };