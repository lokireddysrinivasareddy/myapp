"use strict"

let s;

document.querySelector('.add-btn').addEventListener('click', function (e) {
    e.preventDefault();
    let n1 = Number(document.querySelector('.num1').value);
    let n2 = Number(document.querySelector('.num2').value);
    console.log(n1);
    console.log(n2);
    s = n1 + n2;
    document.querySelector('.result').value = s;
    console.log(s)
});

document.querySelector('.sub-btn').addEventListener('click', function (e) {
    e.preventDefault();
    let n1 = Number(document.querySelector('.num1').value);
    let n2 = Number(document.querySelector('.num2').value);
    console.log(n1);
    console.log(n2);
    s = n1 - n2;
    document.querySelector('.result').value = s;
    console.log(s)
});

document.querySelector('.mul-btn').addEventListener('click', function (e) {
    e.preventDefault();
    let n1 = Number(document.querySelector('.num1').value);
    let n2 = Number(document.querySelector('.num2').value);
    console.log(n1);
    console.log(n2);
    s = n1 * n2;
    document.querySelector('.result').value = s;
    console.log(s)
});

document.querySelector('.div-btn').addEventListener('click', function (e) {
    e.preventDefault();
    let n1 = Number(document.querySelector('.num1').value);
    let n2 = Number(document.querySelector('.num2').value);
    console.log(n1);
    console.log(n2);
    s = n1 / n2;
    document.querySelector('.result').value = s;
    console.log(s)
});



const arr=[1,2,3,4,5,6,7];
console.log(...arr);
const a2=[]
a2.push(...arr)
console.log(a2)

console.log(1+'2')
console.log(Math.round(23.5))

console.log(2 ** 53 + 0);
console.log(15n === 15.0);

let tex="string"
console.log(tex.substring(1,4));



let today=new Date();
var cmas=new Date(today.getFullYear(),11,25);
if (today.getMonth()==11 && today.getDate()>25) 
{
cmas.setFullYear(cmas.getFullYear()+1); 
} 
// cmas.setFullYear(2022); 
var one_day=1000*60*60*24;
console.log(Math.ceil((cmas.getTime()-today.getTime())/(one_day))+
" days left until Christmas!");