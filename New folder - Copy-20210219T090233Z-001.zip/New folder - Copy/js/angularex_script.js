var app =   angular
            .module('myModule',[])
            .controller('myController', function($scope){
                var employees =[
                    {name : 'Joy', dateOfBirth : new Date("November 14, 1990"), gender : 'Male', salary : 50000},
                    {name : 'Raghu', dateOfBirth : new Date("July 20, 1995"), gender : 'Male', salary : 53000},
                    {name : 'Harini', dateOfBirth : new Date("march 14, 1994"), gender : 'Female', salary : 45000},
                    {name : 'Kiran', dateOfBirth : new Date("August 14, 1991"), gender : 'Male', salary : 63000},
                    {name : 'Karunya', dateOfBirth : new Date("January 14, 1999"), gender : 'Female', salary : 39000}
                ]
                $scope.employees = employees;
                $scope.sortColumn = "name";
                $scope.reverseSort  = false ;

                $scope.sortData =function(column){
                    $scope.reverseSort = ( $scope.sortColumn == column) ? !$scope.reverseSort : false;
                    $scope.sortColumn = column;
                }

                $scope.getSortClass = function(column){
                    if($scope.sortColumn == column)
                        return $scope.reverseSort ? 'arrow-down' : 'arrow-up';
                    return '';
                }
                // return '';
                $scope.employeeView = "EmployeeTable.html";
            });