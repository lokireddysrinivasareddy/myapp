"use strict"
// 
// let ctype=document.getElementById("court_type");
// console.log(ctype.options[ctype.selectedIndex].text);
// console.log(ctype.options[ctype.selectedIndex].value);
// document.querySelector(".courttype").textContent = ctype.options[ctype.selectedIndex].text;

// document.querySelector(".case_num").textContent = Number(document.querySelector("#case_no").value);
// let ctype=document.getElementById("court_type").value;
    // document.querySelector(".courttype").textContent = "hello";
// function myFunction(){
//     console.log("button clicked");
//     // let ctype=document.getElementById("court_type");
//     // console.log(ctype.value);
//     // document.querySelector(".courttype").innerHTML = ctype.value;
//     // document.querySelector(".case_num").textContent = Number(document.querySelector("#case_no").value);
//     let ctype=document.getElementById("court_type").value;
//     document.querySelector(".courttype").innerHTML = ctype;
// }

// var x = document.getElementById("court_type").value;
// localStorage.setItem("lastname", x);
//   document.querySelector(".courttype").textContent = localStorage.getItem("lastname");

// document.querySelector('.save_btn').addEventListener('click', function(){
//   var a=document.querySelector("#case_no").value;
// console.log(a);
// localStorage.setItem("caseno", a);
// document.querySelector(".case_num").textContent = localStorage.getItem("caseno");
// });

function myFunction() {

  let court_type_obj = document.getElementById("court_type");
  localStorage.setItem("crt", court_type_obj.options[court_type_obj.selectedIndex].text);

  let court_name_obj=document.querySelector('#court_name');
  localStorage.setItem('court__name',court_name_obj.options[court_name_obj.selectedIndex].text)

  let a = document.querySelector("#case_no");
  localStorage.setItem("caseno", a.value);

  let case_type_obj=document.querySelector("#case_type");
  localStorage.setItem('case__type',case_type_obj.options[case_type_obj.selectedIndex].text);

  let respondent_obj=document.querySelector("#respondent");
  localStorage.setItem('respondent__name',respondent_obj.value);

  let petitioner_obj =document.querySelector('#petitioner');
  localStorage.setItem('petitioner__name',petitioner_obj.value);

  let select_respondent_advocate_obj = document.querySelector("#select_advocate");
  localStorage.setItem("select_respondent_advocate", select_respondent_advocate_obj.options[select_respondent_advocate_obj.selectedIndex].text);;

  let pet_advocate_id_obj = document.querySelector("#pet_advocate_id");
  localStorage.setItem("petitioner_advocate",pet_advocate_id_obj.value);

  let bus_details_obj=document.querySelector('#busdet');
  localStorage.setItem("busdet_text", bus_details_obj.value);

  let nex_purpose_obj= document.querySelector("#np");
  localStorage.setItem("ne_purpose",nex_purpose_obj.value);

  let date_obj = document.querySelector("#nhd");
  localStorage.setItem("date",date_obj.value);

  let ben_type_obj = document.querySelector("#div_ben");
  localStorage.setItem("type", ben_type_obj.options[ben_type_obj.selectedIndex].text);

  let judge_obj = document.querySelector("#judge");
  localStorage.setItem("judge_name", judge_obj.value);


  // let img_obj = document.querySelector("#upf");
  // localStorage.setItem("img_file_url", img_obj.value);
  // document.getElementById("courttype").innerHTML = localStorage.getItem("crt");

}
