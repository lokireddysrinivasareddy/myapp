"use strict"

document.getElementById("plusicon").addEventListener('click', function(){
    console.log("button clicked");
   document.querySelector('.minus-icon').classList.remove('hidden');
//    document.querySelector('.minus-icon').classList.remove('over');
    var elements = document.querySelector('.addextension');
    for(var k in elements){
        var div = document.createElement('div');
        div.className='.addextension';
        elements.appendChild("div");
    }
});